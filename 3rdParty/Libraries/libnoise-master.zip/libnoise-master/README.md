# libnoise
libnoise configured for x64 build
http://libnoise.sourceforge.net/downloads/index.html
